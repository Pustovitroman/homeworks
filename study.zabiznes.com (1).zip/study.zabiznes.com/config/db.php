<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=romal590_mybase',
    'username' => 'romal590_mybase',
    'password' => 'romal590_mybase',
    'charset' => 'utf8',
];
